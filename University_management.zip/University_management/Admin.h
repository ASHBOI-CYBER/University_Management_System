#include <iostream>
#include"User.h"
#include"Quiz.h"
using namespace std;

class Admin {
    User LogStudents;
    User LogTeachers;
    Quiz quiz;
    string QuizAnswers[5];
    Course* courses;
    Teacher* TeacherRecord;
    Student* StudentRecord;
    int Student_index;
    int Teacher_index;
public:
    Admin();
    void viewGuestCourseeDetails();
    void viewGuestTeacherDetails();
    void viewGuestStudentDetails();
    void viewGuestDetails();
    void TeacherCourseInformation();
    void StudentChangePassword();
    void TeacherChangePassword();
    void TeacherLoginCheck();
    void StudentLoginCheck();
    void RegisterCourses();
    void CheckQuizScore();
    void ViewRegisteredCourses();
    void TeachersMainMenu();
    void StudentsMainMenu();
    void StoreDataFromCSVFile();
    void StudentTakeQuiz();
    void Logout();
    void TeacherOrganizeQuiz();
    void StudentsAttendence();
    void GenerateAttendenceList();
    void GenerateMarksList();
    void WriteAttendenceOnDisk();
    void WriteMarksOnDisk();
};
