#include <iostream>
#include <string>
#include"User.h"
using namespace std;

User::User() {
    name = "";
    email = "";
    password = "";
}
string User::getName() {
    return name;
}
void User::setName(string name) {
    this->name = name;
}
string User::getEmail() {
    return email;
}
string User::getPassword() {
    return password;
}
void User::setEmail(string email) {
    this->email = email;
}
void User::setPassword(string password) {
    this->password = password;
}
istream& operator>>(istream& in, User& log1) {
    string email, password;
    cout << "Email: ";
    getline(cin, email);
    cout << "Password: ";
    getline(cin, password);
    log1.setEmail(email);
    log1.setPassword(password);
    return in;
}
