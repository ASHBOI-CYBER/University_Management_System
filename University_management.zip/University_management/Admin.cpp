#include <iostream>
#include <string>
#include <fstream>
#include <string>
#include <sstream>
#include"Admin.h"
using namespace std;

const int ROWS = 216; // Maximum number of rows 

Admin::Admin() {
    StudentRecord = new Student[216];
    TeacherRecord = new Teacher[11];
    courses = new Course[11];
    Student_index = 0;
    Teacher_index = 0;
    LogStudents;
    LogTeachers;
    quiz; 
}
void Admin::TeacherLoginCheck() {
    bool flag = false;
    while (flag != true) {
        cin >> LogTeachers;
        for (int i = 0; i < ROWS; i++) {
            if (LogTeachers.getEmail() == (TeacherRecord[i].getEmail())) {
                if (LogTeachers.getPassword() == TeacherRecord[i].getPassword()) {
                    flag = true;
                    Teacher_index = i;
                    break;
                }
                else {
                    flag = false;
                    break;
                }
            }
        }
        if (flag == true) {
            cout << endl;
            TeachersMainMenu();
        }
        else
            cout << "Wrong Credentials, Please Try Again..." << endl;
    }
}
void Admin::StudentLoginCheck() {
    bool flag = false;
    while (flag != true) {
        cin >> LogStudents;
        for (int i = 0; i < ROWS; i++) {
            if (LogStudents.getEmail() == (StudentRecord[i].getEmail())) {
                if (LogStudents.getPassword() == StudentRecord[i].getPassword()) {
                    flag = true;
                    Student_index = i;
                    break;
                }
                else {
                    flag = false;
                    break;
                }
            }
        }
        if (flag == true) {
            cout << endl;
            StudentsMainMenu();
        }
        else
            cout << "Wrong Credentials, Please Try Again..." << endl;
    }
}
void Admin::RegisterCourses() {
    if (StudentRecord[Student_index].getCourseCount() < 7) {
        int choice;
        int newIndex;
        cout << "\nCourses Available..." << endl;
        cout << "---------------------------------------------------" << endl;
        for (int i = 0; i < 11; i++) {
            cout << i + 1 << ": " << TeacherRecord[i].getCourse() << endl;
        }
        cout << "---------------------------------------------------" << endl;
        cout << "\nPlease Note that you can only register 5 or 7 courses at a time." << endl;
        cout << "\nEnter your choice (1-11): ";
        cin >> choice;
        bool flag = false;
        int i = 0;
        for (; i < 11; i++) {
            if (choice == i + 1) {
                for (int j = 0; j < StudentRecord[Student_index].getCourseCount(); j++) {
                    if (TeacherRecord[i].getCourse() == StudentRecord[Student_index].getCourse(j)) {
                        flag = true;
                        break;
                    }
                    else {
                        newIndex = i;
                    }
                }
            }
        }
        if (flag == true) {
            cout << "Course Already Registered..." << endl;
        }
        else {
            StudentRecord[Student_index].setCourse(StudentRecord[Student_index].getCourseCount(), TeacherRecord[newIndex].getCourse());
            StudentRecord[Student_index].setCourseCount(StudentRecord[Student_index].getCourseCount() + 1);
            cout << "Course Registered..." << endl;
        }
        char choice1 = 'Y';
        while (choice1 == 'Y' || choice1 == 'y') {
            cout << "\nDo you want to register more? (Y/N) ";
            cin >> choice1;
            if (choice1 == 'Y' || choice1 == 'y') {
                if (StudentRecord[Student_index].getCourseCount() < 7) {
                    cout << "Enter your choice (1-11): ";
                    cin >> choice;
                    bool flag = false;
                    int i = 0;
                    for (; i < 11; i++) {
                        if (choice == i + 1) {
                            for (int j = 0; j < StudentRecord[Student_index].getCourseCount(); j++) {
                                if (TeacherRecord[i].getCourse() == StudentRecord[Student_index].getCourse(j)) {
                                    flag = true;
                                    break;
                                }
                                else {
                                    newIndex = i;
                                }
                            }
                        }
                    }

                    if (flag == true) {
                        cout << "Course Already Registered..." << endl;
                    }
                    else {
                        StudentRecord[Student_index].setCourse(StudentRecord[Student_index].getCourseCount(), TeacherRecord[newIndex].getCourse());
                        StudentRecord[Student_index].setCourseCount(StudentRecord[Student_index].getCourseCount() + 1);
                        cout << "Course Registered..." << endl;
                        i = 0;
                    }
                }
                else {
                    cout << "Maximum number of courses registered..." << endl;
                    cout << "---------------------------------------------------" << endl;
                    system("pause");
                    system("cls");
                    StudentsMainMenu();
                }
            }
            else {
                cout << "---------------------------------------------------" << endl;
                system("pause");
                system("cls");
                StudentsMainMenu();
            }
        }
    }
    else {
        cout << "Maximum number of courses Registered" << endl;
        cout << "---------------------------------------------------" << endl;
        system("pause");
        system("cls");
        StudentsMainMenu();
    }

}
void Admin::ViewRegisteredCourses() {
    cout << "---------------------------------------------------" << endl;
    for (int i = 0; i < StudentRecord[Student_index].getCourseCount(); i++) {
        cout << i + 1 << ": " << StudentRecord[Student_index].getCourse(i) << endl;
    }
    cout << "---------------------------------------------------" << endl;
    system("pause");
    system("cls");
    StudentsMainMenu();
}
void Admin::TeachersMainMenu() {
    int choice;
    cout << "\t\tMain Menu" << endl;
    cout << "---------------------------------" << endl;
    cout << "1. View Course Information" << endl;
    cout << "2. Organize A Quiz" << endl;
    cout << "3. Change your password" << endl;
    cout << "4. Generate Attendence List" << endl;
    cout << "5. Generate Marks List" << endl;
    cout << "6. Write Attendence List on Disk" << endl;
    cout << "7. Write Marks List on Disk" << endl;
    cout << "8. Logout" << endl;
    cout << "9. Exit the Program" << endl;
    cout << "---------------------------------" << endl;
    cout << "\nPlease, Enter your choice: ";
    cin >> choice;
    switch (choice) {
    case 1:TeacherCourseInformation(); break;
    case 2:TeacherOrganizeQuiz(); break;
    case 3:TeacherChangePassword(); break;
    case 4:GenerateAttendenceList(); break;
    case 5:GenerateMarksList(); break;
    case 6:WriteAttendenceOnDisk(); break;
    case 7:WriteMarksOnDisk(); break;
    case 8:Logout(); break;
    case 9:exit(0);
    default:cout << "Invalid Choice..." << endl;
    }
}
void Admin::viewGuestCourseeDetails() {
    cout << "Total Number of Courses: " << 11 << endl;
    cout << "---------------------------------" << endl;
    for (int i = 0; i < 11; i++) {
        cout << i+1 << ". " << TeacherRecord[i].getCourse() << endl;
    }
    cout << "---------------------------------" << endl;
    system("pause");
    system("cls");
    viewGuestDetails();
}

void Admin::viewGuestTeacherDetails() {
    cout << "Total Number of Teachers: " << 11 << endl;
    cout << "---------------------------------" << endl;
    for (int i = 0; i < 11; i++) {
        cout << i + 1 << ". " << TeacherRecord[i].getName() << endl;
    }
    cout << "---------------------------------" << endl;
    system("pause");
    system("cls");
    viewGuestDetails();
}
void Admin::viewGuestStudentDetails() {
    cout << "Total number of Students: " << 214 << endl;
    cout << "---------------------------------" << endl;
    int temp = 1;
    for (int i = 2; i < 216; i++) {
        cout << temp << ". " << StudentRecord[i].getName() << endl; temp++;
    }
    cout << "---------------------------------" << endl;
    system("pause");
    system("cls");
    viewGuestDetails();
}
void Admin::viewGuestDetails() {
    cout << "\t\tMain Menu" << endl;
    cout << "---------------------------------" << endl;
    cout << "1. View Student Names" << endl;
    cout << "2. View Teacher Names" << endl;
    cout << "3. View Courses Names" << endl;
    cout << "4. Logout" << endl;
    cout << "5. Exit the Program" << endl;
    cout << "---------------------------------" << endl;
    int choice;
    cout << "Please, Enter your choice: ";
    cin >> choice;
    switch (choice) {
    case 1:viewGuestStudentDetails(); break;
    case 2:viewGuestTeacherDetails(); break;
    case 3:viewGuestCourseeDetails(); break;
    case 4:Logout(); break;
    case 5:exit(0); break;
    default:cout << "Invalid Choice..." << endl;
    }
}
void Admin::TeacherCourseInformation() {
    cout << "---------------------------------------------------" << endl;
    cout << "Teacher Name: "<< TeacherRecord[Teacher_index].getName() << endl;
    cout << "Teacher Course: " << TeacherRecord[Teacher_index].getCourse() << endl;
    cout << "---------------------------------------------------" << endl;
    system("pause");
    system("cls");
    TeachersMainMenu();
}
void Admin::TeacherChangePassword() {
    string newPass;
    cout << "---------------------------------" << endl;
    cout << "Please, Enter your new Password: ";
    cin.ignore();
    getline(cin, newPass);
    TeacherRecord[Teacher_index].setPassword(newPass);
    cout<<"Password Updated..." << endl;
    cout << "---------------------------------" << endl;
    system("pause");
    TeachersMainMenu();
}
void Admin::StudentChangePassword() {
    string newPass;
    cout << "---------------------------------" << endl;
    cout << "Please, Enter your new Password: ";
    cin.ignore();
    getline(cin, newPass);
    StudentRecord[Student_index].setPassword(newPass);
    cout << "Password Updated..." << endl;
    cout << "---------------------------------" << endl;
    system("pause");
    StudentsMainMenu();
}
void Admin::Logout() {
    system("cls");
    bool flag = false;
    int choice;
    while (flag == false) {
        cout << "\t\tWelcome to FAST Examination System\n\tSign In" << endl;
        cout << "1. Teacher" << endl;
        cout << "2. Student" << endl;
        cout << "Who Are You (1-2)? ";
        cin >> choice;
        if (choice == 1) {
            flag = true;
            cin.ignore();
            TeacherLoginCheck();
        }
        else if (choice == 2) {
            flag = true;
            cin.ignore();
            StudentLoginCheck();
        }
        else {
            cout << "Invalid Choice..." << endl;
            system("pause");
            system("cls");
        }
    }
}
void Admin::StudentsAttendence() {
    cout << "---------------------------------------------------" << endl;
    for (int i = 0; i < StudentRecord[Student_index].getCourseCount(); i++) {
        cout << i + 1 << ") " << StudentRecord[Student_index].getCourse(i) << ": " << StudentRecord[Student_index].getAttendence(i) << endl;
    }
    cout << "---------------------------------------------------" << endl;
    system("pause");
    system("cls");
    StudentsMainMenu();
}
void Admin::StudentsMainMenu() {
    int choice;
    cout << "\t\tMain Menu" << endl;
    cout << "---------------------------------" << endl;
    cout << "1. Register New Courses" << endl;
    cout << "2. View Registered Courses" << endl;
    cout << "3. Change Password" << endl;
    cout << "4. Check Attendence" << endl;
    cout << "5. Take A Quiz" << endl;
    cout << "6. View Quiz Marks" << endl;
    cout << "7. Logout" << endl;
    cout << "8. Exit the Program" << endl;
    cout << "---------------------------------" << endl;
    cout << "\nPlease, Enter your choice: ";
    cin >> choice;
    switch (choice) {
    case 1:RegisterCourses(); break;
    case 2:ViewRegisteredCourses(); break;
    case 3:StudentChangePassword(); break;
    case 4:StudentsAttendence(); break;
    case 5:StudentTakeQuiz(); break;
    case 6:CheckQuizScore();break;
    case 7:Logout(); break;
    case 8:exit(0);
    default:cout << "Invalid Choice..." << endl;
    }
}
void Admin::StoreDataFromCSVFile() {
    ifstream inputFile("Students.csv");
    ifstream inputFile2("Course Topics.csv");
    ifstream inputFile3("TrueFalse.csv");
    ifstream inputFile4("MCQS.csv");
    ifstream inputFile5("MCQS Options.csv"); 
    ifstream inputFile6("Questions.csv");
    ifstream inputFile7("Answers.csv");

    if (!inputFile.is_open()) {
        cout << "Failed to open file 1!" << endl;
        exit(0);
    }
    if (!inputFile2.is_open()) {
        cout << "Failed to open file 2!" << endl;
        exit(0);
    }
    if (!inputFile3.is_open()) {
        cout << "Failed to open file 3!" << endl;
        exit(0);
    }
    if (!inputFile4.is_open()) {
        cout << "Failed to open file4!" << endl;
        exit(0);
    }
    if (!inputFile5.is_open()) {
        cout << "Failed to open file 5!" << endl;
        exit(0);
    }
    if (!inputFile6.is_open()) {
        cout << "Failed to open file 6!" << endl;
        exit(0);
    }
    if (!inputFile7.is_open()) {
        cout << "Failed to open file 7!" << endl;
        exit(0);
    }
    string line;

    int row = 0;
    int col_count = 1;
    int i = 0;
    int j = 0;
    int k = 0;
    string Domain = "@nu.edu.pk";
    string pass = "123$";

    while (getline(inputFile, line)) {
        if (row >= ROWS) {
            break;
        }
        stringstream lineStream(line);
        string cell;

        if (row == 0) {
            while (getline(lineStream, cell, ','))                        
            {
                if (col_count >= 4) {
                    TeacherRecord[k].setName(cell);
                    k++;
                }
                col_count++;
            }
        }
        if (row == 1) {
            while (getline(lineStream, cell, ','))
            {
                if (col_count >= 4) {
                    courses[k].setCourseName(cell);
                    TeacherRecord[k].setCourse(cell);
                    k++;
                }
                col_count++;
            }
        }
        col_count = 1;
        k = 0;
        int free = 0;
        StudentRecord[i].setCourseCount(0);
        while (getline(lineStream, cell, ','))
        {
            if (row < ROWS) {
                if (col_count == 2) {
                    StudentRecord[i].setRoll_no(cell);
                }
                if (col_count == 3) {
                    StudentRecord[i].setName(cell);
                }
                if (col_count >= 4) {
                    if (cell == "1" && StudentRecord[i].getCourseCount() <= 7) {
                        free = col_count - 4;
                        StudentRecord[i].setCourse(j, TeacherRecord[free].getCourse());
                        StudentRecord[i].setCourseCount(StudentRecord[i].getCourseCount() + 1);
                        j++;
                    }
                }
                col_count++;
            }
        }
        row++;
        i++;
        j = 0;
        col_count = 1;
    }
    inputFile.close();

    row = 0;
    col_count = 1;
    i = 0;
    while (getline(inputFile2, line)) {
        if (row >= 11) {
            break;
        }
        stringstream lineStream(line);
        string cell;

        while (getline(lineStream, cell, ','))
        {
            courses[row].setTopic(i, cell);
            i++;
            col_count++;
        }
        row++;
        i = 0;
    }
    row = 0;
    col_count = 1;
    i = 0;
    k = 0;
    int l = 0;
    while (getline(inputFile3, line)) {
        if (row >= 15) {
            break;
        }
        stringstream lineStream(line);
        string cell;

        while (getline(lineStream, cell, ','))
        {
            if (l == 0) {
                courses[i].setTrueFalseQuestion(k, cell);
            }
            else {
                courses[i].setTrueFalseAnswer(k, cell);
            }
            l++;
        }
        l = 0;
        k++;
        if (k == 5) {
            k = 0;
            i++;
        }
    }
    row = 0;
    col_count = 1;
    i = 0;
    k = 0;
    l = -1;
    while (getline(inputFile4, line)) {
        if (row >= 55) {
            break;
        }
        stringstream lineStream(line);
        string cell;

        while (getline(lineStream, cell, ','))
        {
            if (l == -1) {
                courses[i].setMcQsQuestion(k, cell);
            }
            else {
                courses[i].setMcQsOptions(k, l, cell);
            }
            l++;
        }
        l = -1;
        k++;
        if (k == 5) {
            k = 0;
            i++;
        }
    }
    row = 0;
    col_count = 1;
    i = 0;
    k = 0;
    l = -1;
    while (getline(inputFile5, line)) {
        if (row >= 55) {
            break;
        }
        stringstream lineStream(line);
        string cell;

        while (getline(lineStream, cell, ','))
        {
            courses[i].setMcQsAnswers(k, cell);
        }
        k++;
        if (k == 5) {
            k = 0;
            i++;
        }
    }
    row = 0;
    col_count = 1;
    i = 0;
    k = 0;
    l = -1;
    while (getline(inputFile6, line)) {
        if (row >= 55) {
            break;
        }
        stringstream lineStream(line);
        string cell;

        while (getline(lineStream, cell, ','))
        {
            courses[i].setSubjectiveQuestion(k, cell);
        }
        k++;
        if (k == 5) {
            k = 0;
            i++;
        }
    }
    row = 0;
    col_count = 1;
    i = 0;
    k = 0;
    l = -1;
    while (getline(inputFile7, line)) {
        if (row >= 55) {
            break;
        }
        stringstream lineStream(line);
        string cell;

        while (getline(lineStream, cell, ','))
        {
            courses[i].setSubjectiveAnswer(k, cell);
        }
        k++;
        if (k == 5) {
            k = 0;
            i++;
        }
    }
    for (int i = 0; i < 216; i++) {
        StudentRecord[i].setEmail(StudentRecord[i].getRoll_No() + Domain);
        StudentRecord[i].setPassword(StudentRecord[i].getName() + pass);
    }
    for (int i = 0; i < 11; i++) {
        string temp = StudentRecord[i].getEmail();
        for (int j = 0; temp[j] != '\0'; j++) {
            if (temp[j] == ' ') {
                temp[j] = '.';
            }
        }
        StudentRecord[i].setEmail(temp);
    }
    for (int i = 0; i < 216; i++) {
        string temp = StudentRecord[i].getPassword();
        for (int j = 0; temp[j] != '\0'; j++) {
            if (temp[j] == ' ') {
                temp[j] = '.';
            }
        }
        StudentRecord[i].setPassword(temp);
    }
    for (int i = 0; i < 11; i++) {
        TeacherRecord[i].setEmail(TeacherRecord[i].getName() + Domain);
        TeacherRecord[i].setPassword(TeacherRecord[i].getName() + pass);
    }
    for (int i = 0; i < 11; i++) {
        string temp = TeacherRecord[i].getEmail();
        for (int j = 0; temp[j] != '\0'; j++) {
            if (temp[j] == ' ') {
                temp[j] = '.';
            }
        }
        TeacherRecord[i].setEmail(temp);
    }
    for (int i = 0; i < 11; i++) {
        string temp = TeacherRecord[i].getPassword();
        for (int j = 0; temp[j] != '\0'; j++) {
            if (temp[j] == ' ') {
                temp[j] = '.';
            }
        }
        TeacherRecord[i].setPassword(temp);
    }
} 
void Admin::CheckQuizScore() {
    bool flag = false;
    int index = 0;
    for (int i = 0; i < StudentRecord[Student_index].getCourseCount(); i++) {
        if (StudentRecord[Student_index].getCourse(i) == quiz.getCourseName()) {
            flag = true;
            index = i;
            break;
        }
    }
    if (flag == false) {
        cout << "No Recent Quiz has been conducted" << endl;
        StudentsMainMenu();
    }
    if (quiz.getStart() == 'Y' && flag == true) {
        cout << "---------------------------------------------------" << endl;
        cout << "Student Name: " << StudentRecord[Student_index].getName() << endl;
        cout << "Course Name: " << courses[Teacher_index].getCourseName() << endl;
        cout << "Total Marks: " << 10 << endl;
        cout << "Obtained Marks: " << StudentRecord[Student_index].getMarks(index) << endl;
        cout << "---------------------------------------------------" << endl;
        system("pause");
        StudentsMainMenu();
    }
    else {
        cout << "---------------------------------------------------" << endl;
        cout << "Quiz has not been Started by the teacher" << endl;
        cout << "---------------------------------------------------" << endl;
        system("pause");
        system("cls");
        StudentsMainMenu();
    }
}
void Admin::StudentTakeQuiz() {
    bool flag = false;
    int cindex = 0;
    int marks = 0;
    for (int i = 0; i < StudentRecord[Student_index].getCourseCount(); i++) {
        if (StudentRecord[Student_index].getCourse(i) == quiz.getCourseName()) {
            flag = true;
            cindex = i;
            break;
        }
    } 
    if (flag == false) {
        cout << "---------------------------------------------------" << endl;
        cout << "Quiz of your course has not been Started" << endl;
        cout << "---------------------------------------------------" << endl;
        system("pause");
        StudentsMainMenu();
    }
    int index = 0;
    for (int i = 0; i < StudentRecord[Student_index].getCourseCount(); i++) {
        if (StudentRecord[Student_index].getCourse(i) == quiz.getCourseName())
            index = i;
    }
    if (StudentRecord[Student_index].getQuizDone(index) == 'N') {
        if (quiz.getStart() == 'Y' && flag == true) {
            StudentRecord[Student_index].setAttendence(index, 'P');
            StudentRecord[Student_index].setQuizDone(index, 'Y');
            cout << "Student Name: " << StudentRecord[Student_index].getName() << endl;
            cout << "Course Name: " << courses[Teacher_index].getCourseName() << endl;
            cout << "-------------------------------------------------------------------------------------------------------------" << endl;
            Time temp = quiz.getStartTime();
            Time temp2 = quiz.getEndTime();
            cout << "\t\t\tQuiz" << "\t\tQuiz Starting Time: " << temp << "\t\tQuiz Ending Time: " << temp2 << endl;
            if (quiz.getType() == 1) {
                cout << "-------------------------------------------------------------------------------------------------------------" << endl;
                cout << "Following are the Questions of Quiz:\n" << endl;
                for (int j = 0; j < 5; j++) {
                    cout << j + 1 << ") " << courses[Teacher_index].getSubjectiveQuestion(j) << endl;
                }
                cout << "-------------------------------------------------------------------------------------------------------------" << endl;
                system("pause");
                cout << "-------------------------------------------------------------------------------------------------------------" << endl;
                cout << "Write Answers here" << endl;
                cout << "Answer Sheet" << endl;

                for (int i = 0; i < 5; i++) {
                    cout << i + 1 << ") ";
                    cin.ignore();
                    getline(cin, QuizAnswers[i]);
                }
                cout << "Your Answers have been recorded! You can check your score anytime" << endl;
                for (int i = 0; i < 5; i++) {
                    string temp = courses[Teacher_index].getSubjectiveAnswer(i);
                    for (int j = 0; QuizAnswers[i][j] != '\0'; j++) {
                        if (QuizAnswers[i][j] == temp[j]) {
                            marks += 0.1;
                        }
                    }
                }
                if (marks > 10)
                    marks = 10;
                StudentRecord[Student_index].setMarks(index, marks);
                cout << "-------------------------------------------------------------------------------------------------------------" << endl;
                system("pause");
                system("cls");
                StudentsMainMenu();
            }
            else if (quiz.getType() == 2) {
                cout << "--------------------------------------------" << endl;
                cout << "Following are the Questions of Quiz:\n" << endl;
                for (int j = 0; j < 5; j++) {
                    srand(time(0));
                    int k = rand() % 5;
                    cout << j + 1 << ") " << courses[Teacher_index].getMcQsQuestion(k) << endl;
                    for (int l = 0; l < 4; l++) {
                        cout << "\t" << courses[Teacher_index].getMcQsOptions(k, l) << endl;
                    }
                }
                cout << "--------------------------------------------" << endl;
                system("pause");
                cout << "--------------------------------------------------------------------------" << endl;
                cout << "Write a,b,c or d Simply\nNote: Wrong Answer Format will result in straight 0" << endl;
                cout << "Answer Sheet" << endl;
                for (int i = 0; i < 5; i++) {
                    cout << i + 1 << ") ";
                    cin >> QuizAnswers[i];
                }
                cout << "Your Answers have been recorded! You can check your score anytime" << endl;
                for (int i = 0; i < 5; i++) {
                    if (QuizAnswers[i] == courses[Teacher_index].getMcQsAnswers(i)) {
                        marks += 2;
                    }
                }
                StudentRecord[Student_index].setMarks(index, marks);
                cout << "--------------------------------------------------------------------------" << endl;
                system("pause");
                system("cls");
                StudentsMainMenu();
            }
            else if (quiz.getType() == 3) {
                cout << "--------------------------------------------" << endl;
                cout << "Following are the Questions of Quiz:\n" << endl;
                for (int i = 0; i < 5; i++) {
                    cout << i + 1 << ") " << courses[Teacher_index].getTrueFalseQuestion(i) << endl;
                }
                cout << "--------------------------------------------" << endl;
                system("pause");
                cout << "--------------------------------------------------------------------------" << endl;
                cout << "Write True or False Simply\nNote: Wrong Answer Format will result in straight 0" << endl;
                cout << "Answer Sheet" << endl;
                for (int i = 0; i < 5; i++) {
                    cout << i + 1 << ") ";
                    cin >> QuizAnswers[i];
                }
                cout << "Your Answers have been recorded! You can check your score anytime" << endl;
                for (int i = 0; i < 5; i++) {
                    if (QuizAnswers[i] == courses[Teacher_index].getTrueFalseAnswer(i)) {
                        marks += 2;
                    }
                }
                StudentRecord[Student_index].setMarks(index, marks);
                cout << "--------------------------------------------------------------------------" << endl;
                system("pause");
                system("cls");
                StudentsMainMenu();
            }
        }
        else {
            cout << "--------------------------------------------------------------------------" << endl;
            cout << "Quiz has not been Started by the teacher" << endl;
            cout << "--------------------------------------------------------------------------" << endl;
            system("pause");
            system("cls");
            StudentsMainMenu();
        }
    }
    else {
        cout << "--------------------------------------------------------------------------" << endl;
        cout << "You cannot take your quiz again..." << endl;
        cout << "--------------------------------------------------------------------------" << endl;
        system("pause");
        system("cls");
        StudentsMainMenu();
    }
   
}
void Admin::TeacherOrganizeQuiz() {
    int choice;
    cout << "Set Quiz Starting Time: " << endl;
    quiz.setStartTime();
    cout << "Set Quiz Ending Time: " << endl;
    quiz.setEndTime();
    cout << "-------------------" << endl;
    cout << "Quiz Type: " << endl;
    cout << "1. Subjective" << endl;
    cout << "2. MCQs" << endl;
    cout << "3. True/False" << endl;
    cout << "-------------------" << endl;
    cout << "Enter your choice: ";
    cin >> choice;
    if (choice == 1) {
        cout << "--------------------------------------------" << endl;
        cout << "Subjective Quiz" << endl;
        int choice;
        cout << "Note: Please Select 1 Topic...\n" << endl;
        for (int i = 0; i < 3; i++) {
            cout << i + 1 << ") " << courses[Teacher_index].getCourseTopic(i) << endl;
        }
        cout << "--------------------------------------------" << endl;
        cout << "Enter your choice (1-3): ";
        cin >> choice;
        cout << "--------------------------------------------" << endl;
        cout << "Following will be the Questions of Quiz:\n" << endl;
        for (int j = 0; j < 5; j++) {
            cout << j + 1 << ") " << courses[Teacher_index].getSubjectiveQuestion(j) << endl;
        }
        cout << "--------------------------------------------" << endl;
        char ch;
        cout << "Enter Y to Confirm and Start the Quiz: ";
        cin >> ch;
        if (ch == 'Y' || ch == 'y') {
            cout << "--------------------------------------------" << endl;
            cout << "Quiz has been Started..." << endl;
            quiz.setStart('Y');
            quiz.setType(1);
            quiz.setCourseName(courses[Teacher_index].getCourseName());
            cout << "--------------------------------------------" << endl;
            system("pause");
            system("cls");
            TeachersMainMenu();
        }
    }
    else if (choice == 2) {
        cout << "--------------------------------------------" << endl;
        cout << "McQs Quiz" << endl;
        int choice;
        cout << "Note: Please Select 1 Topic...\n" << endl;
        for (int i = 0; i < 3; i++) {
            cout << i + 1 << ") " << courses[Teacher_index].getCourseTopic(i) << endl;
        }
        cout << "--------------------------------------------" << endl;
        cout << "Enter your choice (1-3): ";
        cin >> choice;
        cout << "--------------------------------------------" << endl;
        cout << "Following will be the Questions of Quiz:\n" << endl;
        for (int j = 0; j < 5; j++) {
            cout << j + 1 << ") " << courses[Teacher_index].getMcQsQuestion(j) << endl;
            for (int l = 0; l < 4; l++) {
                cout << "\t" <<courses[Teacher_index].getMcQsOptions(j, l) << endl;
            }
        }
        cout << "--------------------------------------------" << endl;
        char ch;
        cout << "Enter Y to Confirm and Start the Quiz: ";
        cin >> ch;
        if (ch == 'Y' || ch == 'y') {
            cout << "--------------------------------------------" << endl;
            cout << "Quiz has been Started..." << endl;
            quiz.setStart('Y');
            quiz.setType(2);
            quiz.setCourseName(courses[Teacher_index].getCourseName());
            cout << "--------------------------------------------" << endl;
            system("pause");
            system("cls");
            TeachersMainMenu();
        }
    }
    else if (choice == 3) {
        cout << "--------------------------------------------" << endl;
        cout << "True/False Quiz" << endl;
        int choice;
        cout << "Note: Please Select 1 Topic...\n" << endl;
        for (int i = 0; i < 3; i++) {
            cout << i+1 << ") " << courses[Teacher_index].getCourseTopic(i) << endl;
        }
        cout << "--------------------------------------------" << endl;
        cout << "Enter your choice (1-3): ";
        cin >> choice;
        cout << "--------------------------------------------" << endl;
        cout << "Following will be the Questions of Quiz:\n" << endl;
        for (int i = 0; i < 5; i++) {
            cout << i+1 << ") " << courses[Teacher_index].getTrueFalseQuestion(i) << endl;
        }
        cout << "--------------------------------------------" << endl;
        char ch;
        cout << "Enter Y to Confirm and Start the Quiz: ";
        cin >> ch;
        if (ch == 'Y' || ch == 'y') {
            cout << "--------------------------------------------" << endl;
            cout << "Quiz has been Started..." << endl;
            quiz.setStart('Y');
            quiz.setType(3);
            quiz.setCourseName(courses[Teacher_index].getCourseName());
            cout << "--------------------------------------------" << endl;
            system("pause");
            system("cls");
            TeachersMainMenu();
        }
    }
    else
        cout << "Invalid Choice..." << endl;
}
void Admin::GenerateAttendenceList() {
    cout << "--------------------------------------------------------------------------" << endl;
    cout << "\t\tAttendence List" << endl;
    cout <<"Course Name: " << TeacherRecord[Teacher_index].getCourse() << endl;
    int count = 1;
    for (int i = 0; i < 216; i++) {
        for (int j = 0; j < StudentRecord[i].getCourseCount(); j++) {
            if (StudentRecord[i].getCourse(j) == TeacherRecord[Teacher_index].getCourse()) {
                cout << count << ": " << StudentRecord[i].getName() << " : " << StudentRecord[i].getAttendence(j) << endl;
                count++;
                break;
            }
        }
    }
    cout << "--------------------------------------------------------------------------" << endl;
    system("pause");
    system("cls");
    TeachersMainMenu();
}
void Admin::GenerateMarksList() {
    cout << "--------------------------------------------------------------------------" << endl;
    cout << "\t\tMarks List" << endl;
    cout << "Course Name: " << TeacherRecord[Teacher_index].getCourse() << endl;
    int count = 1;
    for (int i = 0; i < 216; i++) {
        for (int j = 0; j < StudentRecord[i].getCourseCount(); j++) {
            if (StudentRecord[i].getCourse(j) == TeacherRecord[Teacher_index].getCourse()) {
                cout << count << ": " << StudentRecord[i].getName() << " : " << StudentRecord[i].getMarks(j) << endl;
                count++;
                break;
            }
        }
    }
    cout << "--------------------------------------------------------------------------" << endl;
    system("pause");
    system("cls");
    TeachersMainMenu();
}
void Admin::WriteAttendenceOnDisk() {
    fstream newFile;
    newFile.open("D:\\Attendence.csv", ios::out);
    if (!newFile.is_open()) {
        cout << "File is not created" << endl;
        cout << "--------------------------------------------------------------------------" << endl;
        system("pause");
        system("cls");
        TeachersMainMenu();
    }
    cout << "--------------------------------------------------------------------------" << endl;
    string S1;
    S1 = "\t\tAttendence List\nCourse Name: " + TeacherRecord[Teacher_index].getCourse() + "\n";
    newFile.write(S1.c_str(), S1.length());
    int count = 1;
    for (int i = 0; i < 216; i++) {
        for (int j = 0; j < StudentRecord[i].getCourseCount(); j++) {
            if (StudentRecord[i].getCourse(j) == TeacherRecord[Teacher_index].getCourse()) {
                S1.clear();
                S1 = StudentRecord[i].getName() + ":\t" + StudentRecord[i].getAttendence(j) + "\n";
                newFile.write(S1.c_str(), S1.length());
                count++;
                break;
            }
        }
    }
    newFile.close();
    cout << "Data Has been written Successfully on Disk" << endl;
    cout << "--------------------------------------------------------------------------" << endl;
    system("pause");
    system("cls");
    TeachersMainMenu();
}
void Admin::WriteMarksOnDisk() {
    fstream newFile;
    newFile.open("D:\\Marks.csv", ios::out);
    if (!newFile.is_open()) {
        cout << "File is not created" << endl;
        cout << "--------------------------------------------------------------------------" << endl;
        system("pause");
        system("cls");
        TeachersMainMenu();
    }
    cout << "--------------------------------------------------------------------------" << endl;
    string S1;
    S1 = "\t\tMarks List\nCourse Name: " + TeacherRecord[Teacher_index].getCourse() + "\n";
    newFile.write(S1.c_str(), S1.length());
    int count = 1;
    for (int i = 0; i < 216; i++) {
        for (int j = 0; j < StudentRecord[i].getCourseCount(); j++) {
            if (StudentRecord[i].getCourse(j) == TeacherRecord[Teacher_index].getCourse()) {
                S1.clear();
                S1 = StudentRecord[i].getName() + ":\t" + to_string(StudentRecord[i].getMarks(j)) + "\n";
                newFile.write(S1.c_str(), S1.length());
                count++;
                break;
            }
        }
    }
    newFile.close();
    cout << "Data Has been written Successfully on Disk" << endl;
    cout << "--------------------------------------------------------------------------" << endl;
    system("pause");
    system("cls");
    TeachersMainMenu();
}