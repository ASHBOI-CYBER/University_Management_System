#include <iostream>
#include"Admin.h"
using namespace std;

int main() {
  
    int choice;
    Admin exam1;
    exam1.StoreDataFromCSVFile();
    bool flag = false;
    while (flag == false) {
        cout << "\t\tWelcome to FAST Examination System\n\tSign In" << endl;
        cout << "1. Teacher" << endl;
        cout << "2. Student" << endl;
        cout << "3. Guest" << endl;
        cout << "Who Are You (1-2)? ";
        cin >> choice;
        if (choice == 1) {
            flag = true;
            cin.ignore();
            exam1.TeacherLoginCheck();
        }
        else if (choice == 2) {
            flag = true;
            cin.ignore();
            exam1.StudentLoginCheck();
        }
        else if (choice == 3) {
            flag = true;
            exam1.viewGuestDetails();
        }
        else {
            cout << "Invalid Choice..." << endl;
            system("pause");
            system("cls");
        }
    }
   
    return 0;
}

