#include<iostream>
#include"User.h"
using namespace std;

Teacher::Teacher() {
	course = "";
}
string Teacher::getCourse() {
	return course;
}
void Teacher::setCourse(string course) {
	this->course = course;
}
ostream& operator<<(ostream& out, Teacher& t1) {
	cout << "Teacher Name: " << t1.getName() << endl;
	cout << "Teacher Email: " << t1.getEmail() << endl;
	cout << "Teacher Course: " << t1.getCourse() << endl;
	return out;
}
