#include <iostream>
#include"User.h"
using namespace std;

Student::Student() {
    roll_no = "";
    for (int i = 0; i < 7; i++) {
        course[i] = "";
    }
    courseCount = 0;
    for (int i = 0; i < 7; i++) {
        Attendence[i] = 'A';
    }
    for (int i = 0; i < 7; i++) {
        QuizDone[i] = 'N';
    }
    for (int i = 0; i < 7; i++) {
        marks[i] = 0;
    }
}

string Student::getRoll_No() {
    return roll_no;
}
string Student::getCourse(int i) {
    return course[i];
}
void Student::setMarks(int i, int marks) {
    this->marks[i] = marks;
}
int Student::getMarks(int i) {
    return marks[i];
}
void Student::setRoll_no(string roll_no) {
    this->roll_no = roll_no;
}
void Student::setCourse(int i, string course) {
    this->course[i] = course;
}
int Student::getCourseCount() {
    return courseCount;
}
void Student::setCourseCount(int i) {
    courseCount = i;
}
void Student::setAttendence(int i, char a) {
    Attendence[i] = a;
}
char Student::getAttendence(int i) {
    return Attendence[i];
}
void Student::setQuizDone(int i, char q) {
    QuizDone[i] = q;
}
char Student::getQuizDone(int i) {
    return QuizDone[i];
}
ostream& operator<<(ostream& out, Student& s1) {
    out << "Name: " << s1.getName() << "\t";
    out << "Roll No: " << s1.getRoll_No() << "\t";
    out << "Email: " << s1.getEmail() << endl;
    out << "---------------------------------" << endl;
    out << "Registered Courses..." << endl;
    int temp = 1;
    for (int i = 0; i < 7; i++) {
        if (s1.getCourse(i) != "") {
            out << temp << ": " << s1.getCourse(i) << endl;
            temp++;
        }
    }
    out << "---------------------------------" << endl;
    return out;
}