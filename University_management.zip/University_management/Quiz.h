#include <iostream>
#include <string>
using namespace std;

class Time {
	int seconds;
	int minutes;
	int hours;
public:
	Time();
	Time operator=(Time& t1);
	int getMinutes();
	int getHours();
	void setHours(int hours);
	void setMinutes(int minutes);
};
ostream& operator<<(ostream& out, Time& t1);
istream& operator>>(istream& in, Time& t1);

class Questions {
protected:
	string questions;
	string answers;
public:
	Questions();
	string getQuestion();
	string getAnswer();
	void setQuestion(string question);
	void setAnswer(string answer);
};
ostream& operator<<(ostream& out, Questions& t1);

class MCQs : public Questions {
	string options[4];
public:
	MCQs();
	void setoptions(int i, string option);
	string getoptions(int i);
	string getAnswer();
};

class Course{
	string name;
	string topics[3];
	Questions* subjective;
	MCQs* mcqs;
	Questions* truefalse;
	int no_of_questions;
	int total_questions;
public:
	Course();
	string getCourseName();
	void setCourseName(string course);
	string getCourseTopic(int i);
	void setTopic(int i, string topic);
	void setSubjectiveQuestion(int i, string question);
	string getSubjectiveQuestion(int i);
	void setSubjectiveAnswer(int i, string answer);
	string getSubjectiveAnswer(int i);
	string getMcQsOptions(int i, int j);
	void setMcQsOptions(int i, int j, string option);
	string getMcQsQuestion(int i);
	string getMcQsAnswers(int i);
	void setMcQsQuestion(int i, string question);
	void setMcQsAnswers(int i, string answer);
	string getTrueFalseQuestion(int i);
	string getTrueFalseAnswer(int i);
	void setTrueFalseQuestion(int i, string question);
	void setTrueFalseAnswer(int i, string answer);
	int getnoQuestions();
	void setnoQuestions(int no);
};
ostream& operator<<(ostream& out, Course c1);

class Quiz {
	Course course;
	Time Start_time;
	Time End_time;
	char Start;
	int type;
	int total_marks;
public:
	Quiz();
	char getStart();
	int getType();
	void setType(int type);
	void setStart(char start);
	Time getStartTime();
	Time getEndTime();
	string getCourseName();
	void setCourseName(string courseName);
	void setStartTime();
	void setEndTime();
	int getTotalMarks();
	void setTotalMarks(int marks);
};

