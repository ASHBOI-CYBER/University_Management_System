#include<iostream>
#include"Quiz.h"
using namespace std;

//McQs Member Functions
MCQs::MCQs() {
	questions = "";
	answers = "";
	for (int i = 0; i < 4; i++)
		options[i] = "";
}
void MCQs::setoptions(int i, string option) {
	 options[i] = option;
}
string MCQs::getAnswer() {
	return answers;
}
//Questions Member Functions
Questions::Questions() {
	questions = "";
	answers = "";
}
string Questions::getQuestion() {
	return questions;
}
string Questions::getAnswer() {
	return answers;
}
void Questions::setQuestion(string question) {
	questions = question;
}
void Questions::setAnswer(string answer) {
	answers = answer;
}
ostream& operator<<(ostream& out, Questions& t1) {
	cout << "Question: " << t1.getQuestion() << endl;
	return out;
}

//Quiz Member Functions
Quiz::Quiz() : total_marks(0) {}
Time Quiz::getStartTime() {
	return Start_time;
}
Time Quiz::getEndTime() {
	return End_time;
}
int Quiz::getTotalMarks() {
	return total_marks;
}
string Quiz::getCourseName() {
	return course.getCourseName();
}
void Quiz::setCourseName(string courseName) {
	course.setCourseName(courseName);
}
void Quiz::setTotalMarks(int marks) {
	total_marks = marks;
}
void Quiz::setStartTime() {
	Time t1;
	cin >> t1;
	Start_time = t1;
}
void Quiz::setEndTime() {
	Time t1;
	cin >> t1;
	End_time = t1;
}
//Course Member Functions
Course::Course() {
	name = "";
	no_of_questions = 0;
	total_questions = 5;
	subjective = new Questions[total_questions];
	truefalse = new Questions[total_questions];
	mcqs = new MCQs[total_questions];
	for (int i = 0; i < 3; i++)
		topics[i] = "";
}
string Course::getCourseName() {
	return name;
}
void Course::setCourseName(string course) {
	this->name = course;
}
string Course::getCourseTopic(int i) {
	return topics[i];
}
void Course::setTopic(int i, string topic) {
	this->topics[i] = topic;
}
void Course::setSubjectiveAnswer(int i, string answer) {
	subjective[i].setAnswer(answer);
}
string Course::getSubjectiveAnswer(int i) {
	return subjective[i].getAnswer();
}
void Course::setSubjectiveQuestion(int i, string question) {
	subjective[i].setQuestion(question);
}
string Course::getSubjectiveQuestion(int i) {
	return subjective[i].getQuestion();
}
char Quiz::getStart() {
	return Start;
}
void Quiz::setStart(char start) {
	this->Start = start;
}
string MCQs::getoptions(int i) {
	return options[i];
}
string Course::getMcQsOptions(int i, int j) {
	return mcqs[i].getoptions(j);
}
string Course::getMcQsQuestion(int i) {
	return mcqs[i].getQuestion();
}
string Course::getMcQsAnswers(int i) {
	return mcqs[i].getAnswer();
}
void Course::setMcQsOptions(int i, int j, string option) {
	mcqs[i].setoptions(j, option);
}
void Course::setMcQsQuestion(int i, string question) {
	mcqs[i].setQuestion(question);
}
void Course::setMcQsAnswers(int i, string answer) {
	mcqs[i].setAnswer(answer);
}
int Quiz::getType() {
	return type;
}
void Quiz::setType(int type) {
	this->type = type;
}
string Course::getTrueFalseQuestion(int i) {
	return truefalse[i].getQuestion();
}
string Course::getTrueFalseAnswer(int i) {
	return truefalse[i].getAnswer();
}
void Course::setTrueFalseQuestion(int i, string question) {
	truefalse[i].setQuestion(question);
}
void Course::setTrueFalseAnswer(int i, string answer) {
	truefalse[i].setAnswer(answer);
}
int Course::getnoQuestions() {
	return total_questions;
}
void Course::setnoQuestions(int no) {
	if (no > 5) {
		no_of_questions = 5;
		cout << "Number of questions cant be greater than 5" << endl;
	}
	else
		this->no_of_questions = no;
} 
ostream& operator<<(ostream& out, Course c1) {
	cout << "Course Name: " << c1.getCourseName() << endl;
	cout << "Course Topics: " << endl;
	for (int i = 0; i < 3; i++) {
		cout << i + 1 << ": " << c1.getCourseTopic(i) << endl;
	}
	return out;
}