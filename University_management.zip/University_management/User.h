#include <iostream>
using namespace std;

class User {
protected:
    string name;
    string email;
    string password;
public:
    User();
    string getEmail(); 
    string getPassword();
    string getName();
    void setName(string name);
    void setEmail(string email);
    void setPassword(string password);
};
istream& operator>>(istream& in, User& log1);

class Teacher : public User {
    string course;
public:
    Teacher();
    string getCourse();
    void setCourse(string course);
};
ostream& operator<<(ostream& out, Teacher& t1);

class Student : public User {
    string roll_no;
    string course[7];
    int courseCount;
    char QuizDone[7];
    char Attendence[7];
    int marks[7];
public:
    Student();
    string getRoll_No();
    string getCourse(int i);
    void setAttendence(int i, char);
    char getAttendence(int i);
    void setQuizDone(int i, char);
    char getQuizDone(int i);
    void setMarks(int i, int);
    int getMarks(int i);
    void setRoll_no(string roll_no);
    void setCourse(int i, string course);
    int getCourseCount();
    void setCourseCount(int i);
};
ostream& operator<<(ostream& out, Student& s1);
