#include<iostream>
#include"Quiz.h"
using namespace std;

//Time Member Functions
Time::Time() {
	minutes = 0;
	hours = 0;
}
Time Time::operator=(Time& t1) {
	minutes = t1.minutes;
	hours = t1.hours;
	return *this;
}
int Time::getMinutes() {
	return minutes;
}
int Time::getHours() {
	return hours;
}
void Time::setHours(int hours) {
	this->hours = hours;
}
void Time::setMinutes(int minutes) {
	this->minutes = minutes;
	if (minutes > 60) {
		hours = hours + (minutes / 60);
		minutes = minutes % 60;
	}
}
ostream& operator<<(ostream& out, Time& t1) {
	if (t1.getMinutes() == 0) {
		out << t1.getHours() << ":00";
	}
	else if (t1.getMinutes() < 10) {
		out << t1.getHours() << ":0" << t1.getMinutes();
	}
	else {
		out << t1.getHours() << ":" << t1.getMinutes();
	}
	return out;
}
istream& operator>>(istream& in, Time& t1) {
	int seconds;
	int minutes;
	int hours;
	cout << "Enter hour: ";
	cin >> hours;
	cout << "Enter minute: ";
	cin >> minutes;
	if (minutes > 60) {
		hours = hours + (minutes / 60);
		minutes = minutes % 60;
	}
	t1.setHours(hours);
	t1.setMinutes(minutes);
	return in;
}